package pt.ulusofona.aed.deisiworldmeter;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final List<Cidade> CIDADES = new ArrayList<>();
    private static final List<Pais> PAISES = new ArrayList<>();
    private static final List<Populacao> POPULACOES = new ArrayList<>();
    private static final List<String> INPUT_INVALIDOS = new ArrayList<>();

    public static void main(String[] args) {
        parseFiles(new File("."));
    }

    public static boolean parseFiles(File folder) {

        CIDADES.clear();
        PAISES.clear();
        POPULACOES.clear();
        INPUT_INVALIDOS.clear();

        if (folder == null || !folder.exists()) {
            return false;
        }

        if (!folder.isDirectory()) {
            folder = folder.getParentFile();
            if (folder == null || !folder.isDirectory()) {
                return false;
            }
        }

        File ficheiroPaises = new File(folder, "paises.csv");
        File ficheiroCidades = new File(folder, "cidades.csv");
        File ficheiroPopulacao = new File(folder, "populacao.csv");

        if (ficheiroPaises.exists()) {
            parsePaises(ficheiroPaises);
        }

        if (ficheiroCidades.exists()) {
            parseCidades(ficheiroCidades);
        }

        if (ficheiroPopulacao.exists()) {
            parsePopulacao(ficheiroPopulacao);
        }

        return true;
    }

    private static void parsePaises(File f) {
        try (Scanner scanner = new Scanner(f)) {

            int lineCount = 0;
            boolean firstLine = true;

            while (scanner.hasNextLine()) {
                String linha = scanner.nextLine();
                lineCount++;

                if (linha.trim().isEmpty()) {
                    continue;
                }

                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String[] partes = linha.split(",", -1);

                if (partes.length != 4) {
                    INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 2 | " + partes.length);
                    continue;
                }

                try {
                    int id = Integer.parseInt(partes[0].trim());
                    String alfa2 = partes[1].trim();
                    String alfa3 = partes[2].trim();
                    String nome = partes[3].trim();

                    if (id <= 0 || alfa2.length() != 2 || alfa3.length() != 3 || nome.isEmpty()) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 2 | " + partes.length);
                        continue;
                    }

                    boolean duplicado = false;
                    for (Pais p : PAISES) {
                        if (p.getId() == id || p.getAlfa2().equals(alfa2)) {
                            duplicado = true;
                            break;
                        }
                    }

                    if (duplicado) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 2 | " + partes.length);
                        continue;
                    }

                    PAISES.add(new Pais(id, alfa2, alfa3, nome));

                } catch (Exception e) {
                    INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 2 | " + partes.length);
                }
            }

        } catch (FileNotFoundException e) {
            // ignorado
        }
    }

    private static void parseCidades(File f) {
        try (Scanner scanner = new Scanner(f)) {

            int lineCount = 0;
            boolean firstLine = true;

            while (scanner.hasNextLine()) {
                String linha = scanner.nextLine();
                lineCount++;

                if (linha.trim().isEmpty()) {
                    continue;
                }

                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String[] partes = linha.split(",", -1);

                if (partes.length != 6) {
                    INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 1 | " + partes.length);
                    continue;
                }

                try {
                    String alfa2 = partes[0].trim();
                    String nome = partes[1].trim();
                    String regiao = partes[2].trim();

                    if (alfa2.isEmpty()) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 1 | " + partes.length);
                        continue;
                    }

                    String popStr = partes[3].trim();
                    String latStr = partes[4].trim();
                    String lonStr = partes[5].trim();

                    if (popStr.isEmpty() || latStr.isEmpty() || lonStr.isEmpty()) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 1 | " + partes.length);
                        continue;
                    }

                    int populacao = (int) Double.parseDouble(popStr.replace(",", "."));
                    double lat = Double.parseDouble(latStr.replace(",", "."));
                    double lon = Double.parseDouble(lonStr.replace(",", "."));

                    if (populacao < 0) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 1 | " + partes.length);
                        continue;
                    }

                    Pais pais = null;
                    for (Pais p : PAISES) {
                        if (p.getAlfa2().equals(alfa2)) {
                            pais = p;
                            break;
                        }
                    }

                    if (pais == null) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 1 | " + partes.length);
                        continue;
                    }

                    pais.addCidade();
                    CIDADES.add(new Cidade(alfa2, nome, regiao, populacao, lat, lon));

                } catch (Exception e) {
                    INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 1 | " + partes.length);
                }
            }

        } catch (FileNotFoundException e) {
            // ignorado
        }
    }

    private static void parsePopulacao(File f) {
        try (Scanner scanner = new Scanner(f)) {

            int lineCount = 0;
            boolean firstLine = true;

            while (scanner.hasNextLine()) {
                String linha = scanner.nextLine();
                lineCount++;

                if (linha.trim().isEmpty()) {
                    continue;
                }

                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String[] partes = linha.split(",", -1);

                if (partes.length != 5) {
                    INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 3 | " + partes.length);
                    continue;
                }

                try {
                    int id = Integer.parseInt(partes[0].trim());
                    int ano = Integer.parseInt(partes[1].trim());
                    int popM = Integer.parseInt(partes[2].trim());
                    int popF = Integer.parseInt(partes[3].trim());
                    double densidade = Double.parseDouble(partes[4].trim().replace(",", "."));

                    if (id <= 0 || ano <= 0 || popM < 0 || popF < 0 || densidade < 0) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 3 | " + partes.length);
                        continue;
                    }

                    boolean existe = false;
                    for (Pais p : PAISES) {
                        if (p.getId() == id) {
                            existe = true;
                            break;
                        }
                    }

                    if (!existe) {
                        INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 3 | " + partes.length);
                        continue;
                    }

                    POPULACOES.add(new Populacao(id, ano, popM, popF, densidade));

                } catch (Exception e) {
                    INPUT_INVALIDOS.add(f.getName() + " | " + lineCount + " | 3 | " + partes.length);
                }
            }

        } catch (FileNotFoundException e) {
            // ignorado
        }
    }

    public static double calcularPopulacaoTotal() {
        double total = 0;
        for (Cidade c : CIDADES) {
            total += c.getPopulacao();
        }
        return total;
    }

    public static ArrayList<?> getObjects(TipoEntidade tipo) {
        if (tipo == TipoEntidade.CIDADE) {
            return new ArrayList<>(CIDADES);
        }
        if (tipo == TipoEntidade.PAIS) {
            return new ArrayList<>(PAISES);
        }
        if (tipo == TipoEntidade.INPUT_INVALIDO) {
            return new ArrayList<>(INPUT_INVALIDOS);
        }
        return new ArrayList<>();
    }

    public static List<Pais> obtemPaisesComIdMaior700() {
        List<Pais> resultado = new ArrayList<>();
        for (Pais p : PAISES) {
            if (p.getId() > 700) {
                resultado.add(p);
            }
        }
        return resultado;
    }
}